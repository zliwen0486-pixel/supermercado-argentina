# Supermercado Argentina Android APP

这是 Android WebView APP 项目。APP 内置最新的免登录网页版本，不依赖 GitHub Pages 才能打开。

## 编译 APK
1. 把整个项目上传到 GitHub 仓库。
2. GitHub Actions 会自动运行 `Build Android APK`。
3. 在 Actions 对应运行记录的 Artifacts 下载 `SupermercadoArgentina-debug`。
4. 解压后得到 `app-debug.apk`，在 Android 手机上安装。

## 功能
- 中文 / Español
- 商品、库存、入库、出库
- 条码
- 销售记录导入 CSV
- 销售统计
- 本地数据保存
- Android 相机权限与文件选择支持
- 无登录，启动直接进入系统
